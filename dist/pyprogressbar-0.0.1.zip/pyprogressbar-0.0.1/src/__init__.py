try:
    from pyprogressbar import Bar
except ImportError:
    from pyprogressbar.pyprogressbar import Bar
